import { sortMap } from "../lib/sort.js";

export function initSorting(columns) {
    return (query, state, action) => {
        let field = null;
        let order = 'none';

        if (action && columns.includes(action)) {
            columns.forEach((column) => {
                if (column === action) {
                    column.value = sortMap[column.value];
                } else {
                    column.value = 'none';
                }
            });
        }

        columns.forEach((column) => {
            if (column.value !== 'none') {
                order = column.value;

                if (column.name === 'sortByDate') {
                    field = 'date';
                }

                if (column.name === 'sortByTotal') {
                    field = 'total';
                }
            }
        });

        const sort = (field && order !== 'none') ? `${field}:${order}` : null;

        return sort ? Object.assign({}, query, { sort }) : query;
    };
}